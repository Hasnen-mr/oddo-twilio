/** @odoo-module **/

import { Component, useExternalListener, useState, onWillStart, onWillUnmount, onWillUpdateProps } from "@odoo/owl";
import { jsonrpc as rpc } from "@web/core/network/rpc_service";
import { useService } from "@web/core/utils/hooks";
import { COUNTRY_CODES } from "./country_codes";
import { deviceManager } from "./device_manager";
import { AutoDialerRunner } from "./auto_dialer_runner";
import { splitPhoneNumber } from "./phone_utils";

const LAST_DIAL_STORAGE_KEY = "twilio_dialer.last_dial";
const CONTACT_PAGE_SIZE = 30;

export class DialerPopup extends Component {
    static template = "twilio_dialer.DialerPopup";
    static components = { AutoDialerRunner };

    static props = {
        onClose: { type: Function, optional: false },
        phone: { type: String, optional: true },
        fromNumber: { type: String, optional: true },
        partnerId: { type: Number, optional: true },
        partnerName: { type: String, optional: true },
        autoDialerId: { type: Number, optional: true },
        requestId: { type: Number, optional: true },
    };

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        const defaultCountry = COUNTRY_CODES.find((country) => country.code === "+91") || COUNTRY_CODES[0];
        const lastDial = this._loadLastDial();
        const savedCountry =
            this._findCountry(lastDial?.countryCode, lastDial?.countryLabel) || defaultCountry;

        const hasAutoDialer = !!(this.props.autoDialerId || this.dialerState.autoDialerId);
        const initialTab = hasAutoDialer ? "auto_dialer" : "dialpad";

        this.state = useState({
            activeTab: initialTab,
            phoneNumber: "",
            lastDialedNumber: lastDial?.phoneNumber || "",
            lastDialedCountryCode: lastDial?.countryCode || savedCountry.code,
            lastDialedFromNumber: lastDial?.fromNumber || "",
            connectionStatus: "initializing",
            isMuted: false,
            dtmfBuffer: "",
            selectedCountry: savedCountry,
            countrySearchQuery: "",
            showCountryDropdown: false,
            showCallerDropdown: false,
            callerNumbers: [],
            selectedCaller: null,
            systemPhoneNumber: "",
            showIncomingKeypad: false,
            callDuration: 0,
            autoDialerList: "",
            contactSearchQuery: "",
            contacts: [],
            contactsOffset: 0,
            contactsHasMore: true,
            contactsLoading: false,
            dndEnabled: deviceManager.isDoNotDisturb,
            refreshingToken: false,
        });

        this._callTimer = null;
        this._callStartTime = null;
        this._contactSearchTimer = null;

        this._applyIncomingPhone(this.props.phone);
        useExternalListener(window, "keydown", this._onKeydown.bind(this));

        onWillStart(async () => {
            await this._loadConfiguredPhoneNumber();
            this._applyFromNumber(this.props.fromNumber || this.state.lastDialedFromNumber);
            
            // Connect UI status change listener to global deviceManager
            deviceManager.setStatusCallback(this._onDeviceStatusChange.bind(this));
            
            // Sync status if deviceManager is already ready or in another state
            if (deviceManager.status) {
                this.state.connectionStatus = deviceManager.status;
            }
        });

        onWillUpdateProps((nextProps) => {
            if (nextProps.requestId !== this.props.requestId) {
                this._applyIncomingPhone(nextProps.phone);
                this._applyFromNumber(nextProps.fromNumber);
                if (this.state.connectionStatus === "incoming") {
                    this.state.activeTab = "dialpad";
                } else if (nextProps.autoDialerId) {
                    this.state.activeTab = "auto_dialer";
                } else if (nextProps.phone && !nextProps.autoDialerId) {
                    this.state.activeTab = "dialpad";
                }
            }
        });

        onWillUnmount(() => {
            clearTimeout(this._contactSearchTimer);
            // Unregister status callback when UI unmounts; DO NOT destroy global deviceManager
            deviceManager.setStatusCallback(null);
        });
    }

    get dialerState() {
        return this.env.services.twilio_dialer?.state || {};
    }

    async onNavigateQueue(actionName) {
        const dialerId = this.dialerState.autoDialerId;
        if (!dialerId) {
            return;
        }
        try {
            const result = await rpc("/twilio_dialer/auto_dialer/navigate", {
                dialer_id: dialerId,
                action_name: actionName,
            });
            if (result && result.success && result.queue_line_id) {
                this.dialerState.queueLineId = result.queue_line_id;
                this.dialerState.partnerName = result.partner_name;
                this.dialerState.queuePosition = result.queue_position;
                this.dialerState.queueAttempts = result.queue_attempts;
                this.dialerState.queueNotes = result.queue_notes;
                this.dialerState.queueStatus = result.queue_status;
                if (result.phone) {
                    this._applyIncomingPhone(result.phone);
                }
            }
        } catch (err) {
            console.error("Queue navigation failed:", err);
        }
    }

    onSkipQueueContact() {
        this.onNavigateQueue("skip");
    }

    onNextQueueContact() {
        this.onNavigateQueue("next");
    }

    onPrevQueueContact() {
        this.onNavigateQueue("prev");
    }

    get isIncoming() {
        return this.state.connectionStatus === "incoming";
    }

    onAcceptCall() {
        console.log("[Twilio JS DialerPopup] User clicked Accept Call button");
        deviceManager.acceptCall();
    }

    onRejectCall() {
        console.log("[Twilio JS DialerPopup] User clicked Decline/Reject Call button");
        deviceManager.rejectCall();
    }

    _loadLastDial() {
        try {
            const raw = window.localStorage.getItem(LAST_DIAL_STORAGE_KEY);
            if (!raw) {
                return null;
            }
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== "object") {
                return null;
            }
            return parsed;
        } catch (error) {
            console.warn("Failed to load last dial settings:", error);
            return null;
        }
    }

    _onKeydown(event) {
        if (event.key === "Escape") {
            event.preventDefault();
            this.closePopup();
        }
    }

    _saveLastDial({ country, phoneNumber, fromNumber }) {
        try {
            window.localStorage.setItem(
                LAST_DIAL_STORAGE_KEY,
                JSON.stringify({
                    countryCode: country?.code || "",
                    countryLabel: country?.label || "",
                    phoneNumber: phoneNumber || "",
                    fromNumber: fromNumber || "",
                    updatedAt: Date.now(),
                })
            );
        } catch (error) {
            console.warn("Failed to save last dial settings:", error);
        }
    }

    _findCountry(countryCode, countryLabel) {
        return (
            COUNTRY_CODES.find((country) => country.code === countryCode) ||
            COUNTRY_CODES.find((country) => country.label === countryLabel) ||
            false
        );
    }

    _applyIncomingPhone(phone) {
        if (!phone) {
            return;
        }
        const { country, nationalNumber } = splitPhoneNumber(phone);
        this.state.selectedCountry = country;
        this.state.phoneNumber = nationalNumber;
    }

    _onDeviceStatusChange(status) {
        this.state.connectionStatus = status;
        if (status === "incoming") {
            this.state.showIncomingKeypad = false;
        }
        if (status === "connected" || status === "connecting" || status === "incoming") {
            this._startTimer();
        } else {
            this._stopTimer();
            this.state.isMuted = false;
            this.state.dtmfBuffer = "";
            this.state.showIncomingKeypad = false;
        }
    }

    _startTimer() {
        if (!this._callTimer) {
            this._callStartTime = Date.now();
            this.state.callDuration = 0;
            this._callTimer = setInterval(() => {
                if (this._callStartTime) {
                    this.state.callDuration = Math.floor((Date.now() - this._callStartTime) / 1000);
                }
            }, 1000);
        }
    }

    _stopTimer() {
        if (this._callTimer) {
            clearInterval(this._callTimer);
            this._callTimer = null;
        }
        this._callStartTime = null;
        this.state.callDuration = 0;
    }

    get formattedCallDuration() {
        const dur = this.state.callDuration || 0;
        const mins = String(Math.floor(dur / 60)).padStart(2, "0");
        const secs = String(dur % 60).padStart(2, "0");
        return `${mins}:${secs}`;
    }

    get fullIncomingDisplayNumber() {
        if (this.props.phone) {
            return this.props.phone;
        }
        if (this.state.phoneNumber) {
            return (this.state.selectedCountry?.code || "") + " " + this.state.phoneNumber;
        }
        return "Unknown Caller";
    }

    get incomingToDisplayNumber() {
        const raw = this.props.fromNumber || this.dialerState.fromNumber || "";
        if (raw && !raw.startsWith("client:") && !raw.startsWith("id_odoo_")) {
            return raw;
        }
        return this.state.selectedCaller?.number || this.state.systemPhoneNumber || "";
    }

    toggleIncomingKeypad() {
        this.state.showIncomingKeypad = !this.state.showIncomingKeypad;
    }

    backToIncomingView() {
        this.state.showIncomingKeypad = false;
    }

    async _loadConfiguredPhoneNumber() {
        const result = await rpc("/twilio_dialer/phone_number");
        this.state.systemPhoneNumber = result.phone_number || "";
        const preferredNumber =
            this.props.fromNumber ||
            this.state.selectedCaller?.number ||
            result.phone_number;
        const numbers = result.phone_numbers || [];
        const callers = [];
        const seen = new Set();

        for (const item of numbers) {
            const number = item.phone_number;
            if (!number || seen.has(number)) {
                continue;
            }
            seen.add(number);
            const isOutgoingCallerId = item.type === "outgoing_caller_id";
            callers.push({
                number,
                type: isOutgoingCallerId ? "outgoing_caller_id" : "incoming",
                friendlyName:
                    item.friendly_name ||
                    (isOutgoingCallerId ? "Outgoing Caller ID" : "Twilio Number"),
            });
        }

        if (result.phone_number && !seen.has(result.phone_number)) {
            callers.unshift({
                number: result.phone_number,
                type: "incoming",
                friendlyName: "Twilio Number",
            });
        }

        this.state.callerNumbers = callers;
        this.state.selectedCaller =
            callers.find((caller) => caller.number === preferredNumber) ||
            callers[0] ||
            null;
        if (this.props.fromNumber) {
            this._applyFromNumber(this.props.fromNumber);
        }
    }

    _applyFromNumber(fromNumber) {
        if (!fromNumber) {
            return;
        }
        const existing = this.state.callerNumbers.find(
            (caller) => caller.number === fromNumber
        );
        if (existing) {
            this.state.selectedCaller = existing;
            return;
        }
        const caller = {
            number: fromNumber,
            friendlyName: "Campaign Number",
        };
        this.state.callerNumbers = [...this.state.callerNumbers, caller];
        this.state.selectedCaller = caller;
    }

    _contactDomain() {
        const hasPhone = ["|", ["phone", "!=", false], ["mobile", "!=", false]];
        const query = (this.state.contactSearchQuery || "").trim();
        if (!query) {
            return hasPhone;
        }
        return [
            "&",
            ...hasPhone,
            "|",
            "|",
            "|",
            "|",
            ["name", "ilike", query],
            ["phone", "ilike", query],
            ["mobile", "ilike", query],
            ["parent_name", "ilike", query],
            ["email", "ilike", query],
        ];
    }

    _mapPartnerToContact(partner) {
        const phone = partner.mobile || partner.phone || "";
        const name = partner.name || "Unknown";
        const company =
            partner.commercial_company_name ||
            partner.parent_name ||
            "";
        const companyLabel = company && company !== name ? company : "";
        const parts = name.trim().split(/\s+/);
        const initials = ((parts[0]?.[0] || "") + (parts[1]?.[0] || "")).toUpperCase() || "?";
        return {
            id: partner.id,
            name,
            company: companyLabel,
            phone,
            initials,
        };
    }

    async _loadContacts({ reset = false } = {}) {
        if (this.state.contactsLoading) {
            return;
        }
        if (!reset && !this.state.contactsHasMore) {
            return;
        }

        this.state.contactsLoading = true;
        try {
            const offset = reset ? 0 : this.state.contactsOffset;
            const partners = await this.orm.searchRead(
                "res.partner",
                this._contactDomain(),
                ["name", "phone", "mobile", "parent_name", "commercial_company_name", "email"],
                { limit: CONTACT_PAGE_SIZE, offset, order: "name asc" }
            );
            const mapped = (partners || [])
                .map((partner) => this._mapPartnerToContact(partner))
                .filter((contact) => contact.phone);

            this.state.contacts = reset ? mapped : [...this.state.contacts, ...mapped];
            this.state.contactsOffset = offset + (partners || []).length;
            this.state.contactsHasMore = (partners || []).length >= CONTACT_PAGE_SIZE;
        } catch (error) {
            console.error("Failed to load contacts:", error);
            if (reset) {
                this.state.contacts = [];
                this.state.contactsOffset = 0;
                this.state.contactsHasMore = false;
            }
        } finally {
            this.state.contactsLoading = false;
        }
    }

    setActiveTab(tab) {
        this.state.activeTab = tab;
        this.closeAllDropdowns();
        if (tab === "contacts") {
            this._loadContacts({ reset: true });
        } else if (tab === "settings") {
            this.openConfiguration();
        }
    }

    openAutoCallingSetup() {
        this.action.doAction("twilio_dialer.action_twilio_auto_dialer_menu");
        if (this.props.onClose) {
            this.props.onClose();
        }
    }

    openConfiguration() {
        // Keep / force dialer open while Configuration loads in the main area.
        const dialer = this.env.services.twilio_dialer;
        if (dialer?.state) {
            dialer.state.isOpen = true;
        }
        this.action.doAction("twilio_dialer.action_twilio_configuration_menu");
    }

    openContacts() {
        // Open Contacts in main area; keep dialer open.
        const dialer = this.env.services.twilio_dialer;
        if (dialer?.state) {
            dialer.state.isOpen = true;
        }
        this.action.doAction("contacts.action_contacts");
    }

    openContactDetail(contact) {
        if (!contact?.id) {
            return;
        }
        const dialer = this.env.services.twilio_dialer;
        if (dialer?.state) {
            dialer.state.isOpen = true;
        }
        this.action.doAction({
            type: "ir.actions.act_window",
            name: contact.name || "Contact",
            res_model: "res.partner",
            res_id: contact.id,
            views: [[false, "form"]],
            target: "current",
        });
    }

    onAutoDialerListInput(ev) {
        this.state.autoDialerList = ev.target.value;
    }

    onContactSearch(ev) {
        this.state.contactSearchQuery = ev.target.value;
        clearTimeout(this._contactSearchTimer);
        this._contactSearchTimer = setTimeout(() => {
            this._loadContacts({ reset: true });
        }, 300);
    }

    onContactListScroll(ev) {
        const el = ev.currentTarget;
        if (!el || this.state.contactsLoading || !this.state.contactsHasMore) {
            return;
        }
        if (el.scrollTop + el.clientHeight >= el.scrollHeight - 48) {
            this._loadContacts({ reset: false });
        }
    }

    get filteredContacts() {
        return this.state.contacts;
    }

    _applyContactPhone(contact) {
        if (!contact?.phone) {
            return false;
        }
        const { country, nationalNumber } = splitPhoneNumber(contact.phone);
        this.state.selectedCountry = country;
        this.state.phoneNumber = nationalNumber || contact.phone.replace(/\D/g, "").slice(-15);
        return !!this.state.phoneNumber;
    }

    dialContact(contact) {
        if (!this._applyContactPhone(contact) || this.state.dndEnabled || this.isCallActive) {
            return;
        }
        this.state.activeTab = "dialpad";
        this.closeAllDropdowns();
    }

    callContact(contact) {
        if (!this._applyContactPhone(contact) || this.state.dndEnabled || this.isCallActive) {
            return;
        }
        this.state.activeTab = "dialpad";
        this.closeAllDropdowns();
        // Place the call once the dial pad is active and caller ID is ready.
        Promise.resolve().then(() => {
            if (this.canCall) {
                this.onCall();
            }
        });
    }

    get countryCodes() {
        return COUNTRY_CODES;
    }

    get twilioCallerNumbers() {
        return (this.state.callerNumbers || []).filter(
            (caller) => caller.type !== "outgoing_caller_id"
        );
    }

    get outgoingCallerIds() {
        return (this.state.callerNumbers || []).filter(
            (caller) => caller.type === "outgoing_caller_id"
        );
    }

    get filteredCountries() {
        const query = this.state.countrySearchQuery.toLowerCase().trim();
        if (!query) {
            return COUNTRY_CODES;
        }
        return COUNTRY_CODES.filter(
            (c) =>
                c.name.toLowerCase().includes(query) ||
                c.code.includes(query) ||
                c.label.toLowerCase().includes(query)
        );
    }

    get dialPadKeys() {
        return [
            { digit: "1", letters: "" },
            { digit: "2", letters: "ABC" },
            { digit: "3", letters: "DEF" },
            { digit: "4", letters: "GHI" },
            { digit: "5", letters: "JKL" },
            { digit: "6", letters: "MNO" },
            { digit: "7", letters: "PQRS" },
            { digit: "8", letters: "TUV" },
            { digit: "9", letters: "WXYZ" },
            { digit: "*", letters: "" },
            { digit: "0", letters: "+" },
            { digit: "#", letters: "" },
        ];
    }

    get displayPhoneNumber() {
        const num = this.state.phoneNumber;
        if (!num) {
            return "";
        }
        if (num.length <= 3) {
            return num;
        }
        if (num.length <= 6) {
            return `${num.slice(0, 3)} ${num.slice(3)}`;
        }
        return `${num.slice(0, 3)} ${num.slice(3, 6)} ${num.slice(6)}`;
    }

    get formattedCallerDisplay() {
        const caller = this.state.selectedCaller;
        if (!caller) {
            return "Select number";
        }
        if (caller.friendlyName) {
            return `${caller.friendlyName} (${caller.number})`;
        }
        return caller.number;
    }

    get canRedial() {
        return (
            !!this.state.lastDialedNumber &&
            this.state.lastDialedNumber.length >= 5 &&
            !this.isCallActive &&
            this.state.connectionStatus === "ready" &&
            !this.state.dndEnabled
        );
    }

    get isCallActive() {
        return this.state.connectionStatus === "connecting" || this.state.connectionStatus === "connected";
    }

    get canCall() {
        return (
            this.state.phoneNumber.length >= 5 &&
            this.state.phoneNumber.length <= 15 &&
            !!this.state.selectedCaller &&
            !this.isCallActive &&
            this.state.connectionStatus === "ready" &&
            !this.state.dndEnabled
        );
    }

    get isTokenBusy() {
        return (
            this.state.refreshingToken ||
            ["initializing", "fetching_token", "registering"].includes(this.state.connectionStatus)
        );
    }

    get showTokenOverlay() {
        if (this.isCallActive || this.isIncoming || this.state.dndEnabled) {
            return false;
        }
        return (
            this.isTokenBusy ||
            this.state.connectionStatus === "error" ||
            this.state.connectionStatus === "disconnected"
        );
    }

    get statusClass() {
        const map = {
            initializing: "connecting",
            fetching_token: "connecting",
            registering: "connecting",
            incoming: "connecting",
            connecting: "connecting",
            connected: "ready",
            ready: "ready",
            disconnected: this.state.dndEnabled ? "ready" : "disconnected",
            error: "disconnected",
        };
        return map[this.state.connectionStatus] || "offline";
    }

    get statusLabel() {
        if (this.state.dndEnabled) {
            return "Do Not Disturb";
        }
        const labels = {
            initializing: "Initializing...",
            fetching_token: "Fetching Token...",
            registering: "Registering...",
            incoming: "Incoming Call...",
            connecting: "Connecting...",
            connected: "Connected",
            ready: "Connected",
            disconnected: "Disconnected",
            error: "Failed",
        };
        return labels[this.state.connectionStatus] || "Connected";
    }

    appendDigit(digit) {
        if (this.state.dndEnabled && !this.isCallActive && !this.isIncoming) {
            return;
        }
        if (this.isCallActive) {
            const sent = deviceManager.sendDigits(digit);
            if (sent) {
                this.state.dtmfBuffer = `${this.state.dtmfBuffer || ""}${digit}`.slice(-24);
            }
            return;
        }
        if (digit === "*" || digit === "#") {
            return;
        }
        if (this.state.phoneNumber.length >= 15) {
            return;
        }
        this.state.phoneNumber += digit;
    }

    onToggleMute() {
        if (!this.isCallActive) {
            return;
        }
        this.state.isMuted = deviceManager.toggleMute();
    }

    onHangUp() {
        deviceManager.disconnect();
        this.state.isMuted = false;
        this.state.dtmfBuffer = "";
    }

    onInput(ev) {
        if (this.isCallActive || this.isIncoming || this.state.dndEnabled) {
            ev.target.value = this.state.phoneNumber;
            return;
        }
        this.state.phoneNumber = ev.target.value.replace(/\D/g, "").slice(0, 15);
        ev.target.value = this.state.phoneNumber;
    }

    backspace() {
        if (this.isCallActive || this.isIncoming || this.state.dndEnabled) {
            return;
        }
        this.state.phoneNumber = this.state.phoneNumber.slice(0, -1);
    }

    clearNumber() {
        if (this.isCallActive || this.isIncoming || this.state.dndEnabled) {
            return;
        }
        this.state.phoneNumber = "";
    }

    selectCountry(country) {
        if (this.isCallActive || this.isIncoming || this.state.dndEnabled) {
            return;
        }
        this.state.selectedCountry = country;
        this.state.showCountryDropdown = false;
        this.state.countrySearchQuery = "";
        this._saveLastDial({
            country,
            phoneNumber: this.state.lastDialedNumber || this.state.phoneNumber,
            fromNumber: this.state.selectedCaller?.number || this.state.lastDialedFromNumber,
        });
    }

    toggleCountryDropdown() {
        if (this.isCallActive || this.isIncoming || this.state.dndEnabled) {
            return;
        }
        this.state.showCountryDropdown = !this.state.showCountryDropdown;
        this.state.showCallerDropdown = false;
        if (this.state.showCountryDropdown) {
            this.state.countrySearchQuery = "";
        }
    }

    onCountrySearch(ev) {
        this.state.countrySearchQuery = ev.target.value;
    }

    selectCaller(caller) {
        this.state.selectedCaller = caller;
        this.state.showCallerDropdown = false;
    }

    toggleCallerDropdown() {
        if (this.state.dndEnabled) {
            return;
        }
        this.state.showCallerDropdown = !this.state.showCallerDropdown;
        this.state.showCountryDropdown = false;
    }

    closeAllDropdowns() {
        this.state.showCountryDropdown = false;
        this.state.showCallerDropdown = false;
        this.state.countrySearchQuery = "";
    }

    closeCountryDropdown() {
        this.state.showCountryDropdown = false;
        this.state.countrySearchQuery = "";
    }

    closeCallerDropdown() {
        this.state.showCallerDropdown = false;
    }

    closePopup() {
        this.props.onClose();
    }

    onCall() {
        if (!this.canCall) {
            return;
        }
        const fullNumber = this.state.selectedCountry.code + this.state.phoneNumber;
        this.state.lastDialedNumber = this.state.phoneNumber;
        this.state.lastDialedCountryCode = this.state.selectedCountry.code;
        this.state.lastDialedFromNumber = this.state.selectedCaller?.number || "";
        this._saveLastDial({
            country: this.state.selectedCountry,
            phoneNumber: this.state.phoneNumber,
            fromNumber: this.state.selectedCaller?.number || "",
        });
        deviceManager.makeCall(fullNumber, {
            From: this.state.selectedCaller?.number,
            from_number: this.state.selectedCaller?.number,
        }, {
            partnerId: this.props.partnerId || this.dialerState.partnerId,
            queueLineId: this.dialerState.queueLineId || null,
        });
    }

    onRedial() {
        if (!this.canRedial) {
            return;
        }
        const lastDial = this._loadLastDial() || {};
        const country =
            this._findCountry(
                this.state.lastDialedCountryCode || lastDial.countryCode,
                lastDial.countryLabel
            ) || this.state.selectedCountry;
        const phoneNumber = this.state.lastDialedNumber || lastDial.phoneNumber || "";
        const fromNumber =
            this.state.lastDialedFromNumber ||
            lastDial.fromNumber ||
            this.state.selectedCaller?.number ||
            "";

        this.state.selectedCountry = country;
        this.state.phoneNumber = phoneNumber;
        this.state.activeTab = "dialpad";
        if (fromNumber) {
            this._applyFromNumber(fromNumber);
        }

        if (!this.canCall) {
            return;
        }
        this.onCall();
    }

    async onToggleDnd() {
        if (this.isCallActive || this.isIncoming || this.state.refreshingToken) {
            return;
        }
        const next = !this.state.dndEnabled;
        this.state.dndEnabled = next;
        if (next) {
            this.closeAllDropdowns();
        }
        try {
            await deviceManager.setDoNotDisturb(next);
            this.state.dndEnabled = deviceManager.isDoNotDisturb;
            this.state.connectionStatus = deviceManager.status;
        } catch (err) {
            console.error("[DialerPopup] DND toggle failed:", err);
            this.state.dndEnabled = deviceManager.isDoNotDisturb;
        }
    }

    async onRefreshToken() {
        if (this.state.refreshingToken || this.isCallActive || this.isIncoming) {
            return;
        }
        this.state.refreshingToken = true;
        this.state.dndEnabled = false;
        try {
            const ready = await deviceManager.ensureRegistered({
                regenerate: true,
                timeoutMs: 45000,
            });
            this.state.connectionStatus = deviceManager.status;
            if (!ready) {
                this.state.connectionStatus = "error";
            }
        } catch (err) {
            console.error("[DialerPopup] Token refresh failed:", err);
            this.state.connectionStatus = "error";
        } finally {
            this.state.refreshingToken = false;
        }
    }
}
